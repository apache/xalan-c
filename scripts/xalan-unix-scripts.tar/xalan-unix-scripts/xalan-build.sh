#!/bin/sh

export SourceDir=$HOME/xalan-src/c
# export SourceDir=$HOME/xalan-src/c/trunk

#export DestDir=/usr/local
export DestDir=/opt/apache

export XERCESCROOT=${DestDir}
export XALANCROOT=${SourceDir}

export PATH=$PATH:${SourceDir}
export LD_LIBRARY_PATH=${DestDir}:$LD_LIBRARY_PATH

runConfigure -p linux -c gcc -x g++ -P "${DestDir}" -C "--srcdir=${SourceDir}"

# Connect to subdirectories to build only the libraries and Xalan command line program
# Comment out the subdirectory cd's to also build the sample programs.
cd src
cd xalanc

make clean

make

make install

