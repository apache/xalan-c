#!/bin/sh

export SourceDir=$HOME/xerces-src
#export SourceDir=/data/apache/xerces-src
export DebugDir=/opt/apache/debug

PATH=$PATH:$SourceDir

configure CC="gcc -g" CXX="g++ -g" CFLAGS=-O2 CXXFLAGS=-O2 --srcdir=${SourceDir} --prefix=${DebugDir}

cd src
make clean
make
make install
